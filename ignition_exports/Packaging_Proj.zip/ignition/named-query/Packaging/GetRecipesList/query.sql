SELECT 
    RecipeID AS value, 
    RecipeName AS label 
FROM dbo.Recipes 
ORDER BY RecipeID ASC;