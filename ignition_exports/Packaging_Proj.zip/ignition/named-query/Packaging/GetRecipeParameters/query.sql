SELECT RecipeName, TargetSpeed, RejectLimit
FROM dbo.Recipes
WHERE RecipeID = :recipeID